from django.db import models

class BreastExam(models.Model):
    patient_name = models.CharField(max_length=100)
    age = models.IntegerField()
    lump_present = models.BooleanField(default=False)
    risk_level = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)