from django import forms

class BreastExamForm(forms.Form):
    age = forms.IntegerField(label="Age")
    family_history = forms.BooleanField(label="Family history of breast cancer", required=False)
    lump_present = forms.BooleanField(label="Did you feel a lump?", required=False)
    nipple_discharge = forms.ChoiceField(
        label="Nipple discharge",
        choices=[
            ('none', 'None'),
            ('bloody', 'Bloody'),
            ('clear', 'Clear')
        ]
    )
    skin_changes = forms.BooleanField(label="Any skin changes?", required=False)
    lymph_node_enlargement = forms.BooleanField(label="Swollen lymph nodes?", required=False)
    breast_pain = forms.BooleanField(label="Experiencing breast pain?", required=False)