from django.urls import path
from . import views  # make sure views.py exists in same app

urlpatterns = [
    path('selfExam/', views.breast_exam_view, name='selfExam'),  # 👈 safe, specific route
    # You can add more paths here later
]