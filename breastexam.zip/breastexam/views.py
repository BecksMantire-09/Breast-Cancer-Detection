from django.shortcuts import render

from breastexam.forms import BreastExamForm


def calculate_risk_score(data):
    score = 0
    if data['age'] > 50:
        score += 1
    if data['family_history']:
        score += 2
    if data['lump_present']:
        score += 3
    if data['nipple_discharge'] == 'bloody':
        score += 2
    if data['skin_changes']:
        score += 2
    if data['lymph_node_enlargement']:
        score += 3
    return score



def assess_risk(score):
    if score >= 7:
        return "High Risk – Refer for Imaging Immediately"
    elif score >= 4:
        return "Moderate Risk – Recommend Ultrasound"
    else:
        return "Low Risk – Routine Monitoring"




def breast_exam_view(request):
    score = None
    risk_level = None

    if request.method == 'POST':
        form = BreastExamForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            score = calculate_risk_score(data)
            risk_level = assess_risk(score)
    else:
        form = BreastExamForm()

    return render(request, 'pages/selfExam.html', {
        'form': form,
        'score': score,
        'risk_level': risk_level,
    })